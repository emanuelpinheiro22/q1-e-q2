package Q_01;

public class BancoDoBrasil {
    public static void main(String[] args) {

        ContaCorrente c1 = new ContaCorrente(44980, 1000);
        c1.imprimirSaldo();
        c1.depositar(100);
        c1.imprimirSaldo();
        c1.depositar(400);
        c1.imprimirSaldo();
        c1.sacarDinheiro(200);
        c1.imprimirSaldo();

        ContaPoupanca c2 = new ContaPoupanca(89789, 5000);
        c2.imprimirSaldo();
        c2.depositar(1000);
        c2.imprimirSaldo();
        c2.jurosMensais();
        c2.imprimirSaldo();
    }
}
