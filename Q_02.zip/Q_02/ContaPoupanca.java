package Q_02;

public class ContaPoupanca extends Conta{
    public ContaPoupanca(int numero, float saldo){
        setNumero(numero);
        setSaldo(saldo);
    }

    public void jurosMensais(){
        setSaldo(getSaldo() * 1.005f);
        System.out.println("Número da conta: " + getNumero() + " || juros da poupança aplicado \n");
    }
}
