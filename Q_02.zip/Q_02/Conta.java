package Q_02;

public abstract class Conta {
    private int numero;
    private float saldo;
    
    public int getNumero() {
        return numero;
    }
    public void setNumero(int numero) {
        this.numero = numero;
    }
    public float getSaldo() {
        return saldo;
    }
    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public void depositar(float valor){
        this.saldo += valor;
        System.out.println("Número da conta: " + getNumero() + " || valor depositado: " +valor+ " reais \n");
    }

    public void imprimirSaldo(){
        System.out.println("Conta: " + getNumero());
        System.out.println("Saldo: R$" + getSaldo() + "\n");
    }

    public void sacarDinheiro(float valor){
        this.saldo -= valor;
        System.out.println("Número da conta: " + getNumero() + " || valor sacado: " +valor+ " reais \n");
    }
}

