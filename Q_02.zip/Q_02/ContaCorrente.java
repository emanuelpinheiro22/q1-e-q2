package Q_02;

public class ContaCorrente extends Conta{
    public ContaCorrente(int numero, float saldo){
        setNumero(numero);
        setSaldo(saldo);
    }
}