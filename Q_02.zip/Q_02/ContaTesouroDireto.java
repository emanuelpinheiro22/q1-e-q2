package Q_02;

public class ContaTesouroDireto extends ContaPoupanca{

    public ContaTesouroDireto(int numero, float saldo) {
        super(numero, saldo);
        setNumero(numero);
        setSaldo(saldo);
    }

    public void jurosMensais(){
        setSaldo(getSaldo() * 1.01f);
        System.out.println("Número da conta: " + getNumero() + " || juros aplicado \n");
    }

    public void depositar(float valor){
        if(valor > 1000){
            setSaldo(getSaldo() + valor);
            System.out.println("Número da conta: " + getNumero() + " || valor depositado: " +valor+ " reais \n");
        }
        else{
            System.out.println("Número da conta: " + getNumero() + " || depósito não realizado! \n");
        }
    }
    
}
