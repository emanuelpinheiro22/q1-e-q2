package Q_02;

public class BancoDoBrasil {
    public static void main(String[] args) {

        ContaPoupanca[] c1 = new ContaPoupanca[10];
        c1[0] = new ContaTesouroDireto(1001, 10000);

        c1[1] = new ContaPoupanca(7458, 10000);

        c1[0].imprimirSaldo();        
        c1[1].imprimirSaldo();

        c1[0].depositar(500);
        c1[0].imprimirSaldo();

        c1[1].depositar(500);
        c1[1].imprimirSaldo();

        c1[0].jurosMensais();
        c1[0].imprimirSaldo();
        
        c1[1].jurosMensais();
        c1[1].imprimirSaldo();
    }
}
